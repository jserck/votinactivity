/**
 * Created by lenovo on 2017/9/6.
 */

export const url = {
    baseUrl: 'http://api.cun-tu.cn/activity',
//     baseUrl: 'http://47.93.193.248:8088/activity',
    //  baseUrl:'http://192.168.1.240:8080'
};